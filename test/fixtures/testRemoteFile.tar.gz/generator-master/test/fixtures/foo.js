var foo = 'foo';
