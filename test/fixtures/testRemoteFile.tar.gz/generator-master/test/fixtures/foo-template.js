var <%= foo %> = '<%= foo %>';
